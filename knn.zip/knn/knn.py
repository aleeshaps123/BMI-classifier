import streamlit as st
from sklearn.preprocessing import StandardScaler
from sklearn.neighbors import KNeighborsClassifier
import pandas as pd

# Load the dataset
@st.cache
def load_data():
    dataset = pd.read_csv('dataset.csv')  # replace with your dataset
    return dataset

def main():
    # Load the dataset
    dataset = load_data()

    # Separate features and target variable
    X = dataset[['Weight (kg)', 'Height (cm)']].values  # features: weight and height
    y = dataset['Class'].values  # target: class

    # Feature Scaling
    sc = StandardScaler()
    X_scaled = sc.fit_transform(X)

    # Training the K-NN model
    classifier = KNeighborsClassifier(n_neighbors=5, metric='minkowski', p=2)
    classifier.fit(X_scaled, y)

    # Streamlit interface
    st.title("Predict Underweight/Normal using KNN")

    weight = st.number_input("Enter Weight (kg)", min_value=40, max_value=150, step=1)
    height = st.number_input("Enter Height (cm)", min_value=120, max_value=220, step=1)

    user_input = sc.transform([[weight, height]])  # scale the input data

    # Predicted result
    if st.button('Predict'):
        prediction = classifier.predict(user_input)
        st.write("Prediction:", prediction[0])

if __name__ == "__main__":
    main()